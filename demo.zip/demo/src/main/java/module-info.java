module com.example.demo {
    requires javafx.controls;
    requires javafx.fxml;


    opens fr.metropolis.gestion to javafx.fxml;
    exports fr.metropolis.gestion;
}