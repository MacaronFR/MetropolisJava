package fr.metropolis.gestion;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.util.Callback;

import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class MainController implements Initializable {

    public MainController(){
        columnIDs = new ArrayList<>();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        columnIDs.add(todo);
        columnIDs.add(doing);
        columnIDs.add(done);
    }

    private boolean checkFirstColumn(int id){
        for(int i = id - 1; i >= 0; --i){
            if(columnIDs.get(i) != null){
                return false;
            }
        }
        return true;
    }

    private boolean checkLastColumn(int id){
        for(int i = id + 1; i < columnIDs.size(); ++i){
            if(columnIDs.get(i) != null){
                return false;
            }
        }
        return true;
    }

    private int moveLeft(int from, VBox card){
        for(int i = from - 1; i >= 0; --i){
            if(columnIDs.get(i) != null){
                ((VBox)card.getParent()).getChildren().remove(card);
                ((VBox)((AnchorPane)columnIDs.get(i).getContent()).getChildren().get(0)).getChildren().add(1, card);
                return i;
            }
        }
        return -1;
    }

    private int moveRight(int from, VBox card){
        for(int i = from + 1; i < columnIDs.size(); ++i){
            if(columnIDs.get(i) != null){
                ((VBox)card.getParent()).getChildren().remove(card);
                ((VBox)((AnchorPane)columnIDs.get(i).getContent()).getChildren().get(0)).getChildren().add(1, card);
                return i;
            }
        }
        return -1;
    }

    @FXML
    private HBox kanban;

    @FXML
    private final List<ScrollPane> columnIDs;

    @FXML
    private ScrollPane todo;

    @FXML
    private ScrollPane doing;

    @FXML
    private ScrollPane done;

    @FXML
    protected void onAddClick() {
        ScrollPane newPane = new ScrollPane();
        AnchorPane anchor = new AnchorPane();
        VBox vBox = new VBox();
        HBox hBox = new HBox();
        TextField title = new TextField();
        Button addCard = new Button();
        Button removeColumn = new Button();
        ColumnID cID = new ColumnID();
        newPane.setContent(anchor);
        newPane.setPrefWidth(300);
        columnIDs.add(newPane);
        anchor.getChildren().add(vBox);
        vBox.getChildren().add(hBox);
        hBox.getChildren().add(title);
        hBox.getChildren().add(removeColumn);
        vBox.getChildren().add(addCard);
        title.setText("Titre");
        addCard.setText("Ajouter une carte");
        addCard.setUserData(cID);
        addCard.addEventHandler(MouseEvent.MOUSE_CLICKED, new AddCardHandler());
        removeColumn.setText("X");
        removeColumn.addEventHandler(MouseEvent.MOUSE_CLICKED, new RemoveColumnHandler());
        cID.setId(columnIDs.size()-1);
        removeColumn.setUserData(cID);
        kanban.getChildren().add(kanban.getChildren().size() - 1, newPane);
    }

    private class AddCardHandler implements EventHandler<MouseEvent>{
        @Override
        public void handle(MouseEvent event) {
            onAddCardClick(event);
        }
    }

    private class RemoveColumnHandler implements EventHandler<MouseEvent>{
        @Override
        public void handle(MouseEvent event) {
            removeColumn(event);
        }
    }

    private class RemoveCardHandler implements EventHandler<MouseEvent>{
        @Override
        public void handle(MouseEvent event) {
            removeCard(event);
        }
    }

    @FXML
    protected void onAddCardClick(MouseEvent event){
        ColumnID cID = (ColumnID)((Button)event.getSource()).getUserData();
        VBox vBox = (VBox) ((Button)event.getSource()).getParent();
        VBox card = new VBox();
        HBox head = new HBox();
        TextField title = new TextField("Title");
        Button close = new Button("X");
        Label warning = new Label();
        TextArea description = new TextArea();
        VBox dateContainer = new VBox();
        Label startLabel = new Label("Début");
        DatePicker start = new DatePicker();
        Label endLabel = new Label("Fin");
        DatePicker end = new DatePicker();
        HBox move = new HBox();
        Button left = new Button("<");
        Button right = new Button(">");
        card.getChildren().add(head);
        card.setStyle("-fx-background-color: white");
        head.getChildren().add(title);
        head.getChildren().add(close);
        head.getChildren().add(warning);
        warning.setStyle("-fx-text-fill: red");
        close.addEventHandler(MouseEvent.MOUSE_CLICKED, new RemoveCardHandler());
        startLabel.setLabelFor(start);
        start.addEventHandler(ActionEvent.ACTION, new ChangeStartDate());
        endLabel.setLabelFor(end);
        end.addEventHandler(ActionEvent.ACTION, new ChangeEndDate());
        dateContainer.getChildren().add(startLabel);
        dateContainer.getChildren().add(start);
        dateContainer.getChildren().add(endLabel);
        dateContainer.getChildren().add(end);
        card.getChildren().add(description);
        card.getChildren().add(dateContainer);
        card.getChildren().add(move);
        vBox.getChildren().add(vBox.getChildren().size() - 1, card);
        move.getChildren().add(left);
        left.addEventHandler(MouseEvent.MOUSE_CLICKED, (event1 -> {
            int id = cID.getId();
            if(!checkFirstColumn(id)){
                cID.setId(moveLeft(id, card));
            }
        }));
        move.getChildren().add(right);
        right.setUserData(cID);
        right.addEventHandler(MouseEvent.MOUSE_CLICKED, (event1 -> {
            int id = cID.getId();
            if(!checkLastColumn(id)){
                cID.setId(moveRight(id, card));

            }
        }));
        Draggable.Nature nature = new Draggable.Nature(card);
        nature.addListener((nature1, event1) -> {
            if(event1.equals(Draggable.Event.DragStart)){
                card.setViewOrder(-1.0);
            }
            if(event1.equals(Draggable.Event.DragEnd)){
                if(card.getTranslateY() > 2 * card.getHeight() / 3 || card.getTranslateY() < -2 * card.getHeight() / 3){
                    VBox container = (VBox) card.getParent();
                    int i = container.getChildren().indexOf(card);
                    int newI = ((int) (card.getTranslateY() / card.getHeight())) + i + (card.getTranslateY() > 0 ? 1 : -1);
                    if(newI + 1 >= container.getChildren().size()){
                        newI = container.getChildren().size() - 2;
                    }
                    if(newI < 1){
                        newI = 1;
                    }
                    container.getChildren().remove(i);
                    container.getChildren().add(newI, card);
                }
                card.setTranslateX(0);
                card.setTranslateY(0);
                card.setViewOrder(0.0);
            }
        });
    }

    private class ChangeEndDate implements EventHandler<ActionEvent>{
        @Override
        public void handle(ActionEvent event) {
            changeEndDate(event);
        }
    }

    private class ChangeStartDate implements EventHandler<ActionEvent>{
        @Override
        public void handle(ActionEvent event) {
            changeStartDate(event);
        }
    }

    @FXML
    protected void removeColumn(MouseEvent event){
        ScrollPane s = columnIDs.get(((ColumnID)((Button)event.getSource()).getUserData()).getId());
        columnIDs.set(((ColumnID)((Button)event.getSource()).getUserData()).getId(), null);
        kanban.getChildren().remove(s);
    }

    @FXML
    protected void removeCard(MouseEvent event){
        VBox card = (VBox) ((Button)event.getSource()).getParent().getParent();
        ((VBox)card.getParent()).getChildren().remove(card);
    }

    protected void changeEndDate(ActionEvent event){
        DatePicker end = (DatePicker)event.getSource();
        DatePicker start = (DatePicker) ((VBox)end.getParent()).getChildren().get(1);
        Label warning = (Label)((HBox)((VBox)end.getParent().getParent()).getChildren().get(0)).getChildren().get(2);
        Callback<DatePicker, DateCell> dayCellFactory = dp -> new DateCell(){
            @Override
            public void updateItem(LocalDate item, boolean empty) {
                super.updateItem(item, empty);
                if(end.getValue() != null && item.isAfter(end.getValue())){
                    setStyle("-fx-background-color: #FFC0CB;");
                    Platform.runLater(() -> setDisable(true));
                }
            }
        };
        start.setDayCellFactory(dayCellFactory);
        if(end.getValue().isBefore(LocalDate.now())){
            warning.setText("Dépassé");
        }else{
            warning.setText("");
        }
    }

    protected void changeStartDate(ActionEvent event){
        DatePicker start = (DatePicker)event.getSource();
        DatePicker end = (DatePicker) ((VBox)start.getParent()).getChildren().get(3);
        Callback<DatePicker, DateCell> dayCellFactory = dp -> new DateCell(){
            @Override
            public void updateItem(LocalDate item, boolean empty) {
                super.updateItem(item, empty);
                if(start.getValue() != null && item.isBefore(start.getValue())){
                    setStyle("-fx-background-color: #FFC0CB;");
                    Platform.runLater(() -> setDisable(true));
                }
            }
        };
        end.setDayCellFactory(dayCellFactory);
    }
}